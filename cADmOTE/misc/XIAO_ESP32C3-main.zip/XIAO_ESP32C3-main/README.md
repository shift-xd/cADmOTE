# XIAO_ESP32C3

KiCAD v7 footprint and symbol for XIAO ESP32C3. The pin layout is more intuitive than what I could find online and the battery pads are included.

![symbol_ss](./ext/esp32c3_symbol.png)
